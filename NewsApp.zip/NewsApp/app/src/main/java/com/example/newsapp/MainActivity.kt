package com.example.newsapp

import android.content.Context
import android.content.Intent
import android.content.Loader
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.os.Bundle
import android.preference.PreferenceManager
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import jp.wasabeef.recyclerview.adapters.AlphaInAnimationAdapter
import jp.wasabeef.recyclerview.animators.SlideInLeftAnimator
import jp.wasabeef.recyclerview.animators.SlideInUpAnimator

class MainActivity : AppCompatActivity(),
                     android.app.LoaderManager.LoaderCallbacks<List<Article>>,
                     SharedPreferences.OnSharedPreferenceChangeListener {

    /**
     * Constant value for the articles loader ID. We can choose any integer.
     * This really only comes into play if you're using multiple loaders.
     */
    companion object {
        private const val ARTICLES_LOADER_ID = 1
    }

    /** Adapter for the list of articles */
    private lateinit var mAdapter: ArticlesAdapter

    /** TextView that is displayed when the list is empty  */
    private lateinit var mEmptyStateTextView: TextView

    private lateinit var loadingSpinner: View

    private lateinit var articlesRecycleView: RecyclerView

    private var articlesToShow: Int = 20

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        loadingSpinner = findViewById(R.id.loading_spinner)
        //loadingSpinner.visibility = View.GONE

        articlesRecycleView = findViewById(R.id.list)
        articlesRecycleView.itemAnimator = SlideInLeftAnimator()

        articlesRecycleView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {

                    if(mAdapter.articlesList.size == articlesToShow) {
                        //articlesRecycleView.smoothScrollToPosition(0)
                        //mAdapter.clearData(articlesRecycleView)
                    }
                 /*   val height = articlesRecycleView.getHeight()
                    Log.e("scroll listener", "dx: $dx and dy: $dy and height: $height")
                    val diff = height-dy
                    if (diff < 1000){
                        *//*load next list *//*
                    }*/
            }
        })
        //mEmptyStateTextView = findViewById(R.id.empty_view)
        //articlesRecycleView.empty_view = mEmptyStateTextView

        mAdapter = ArticlesAdapter(mutableListOf<Article>())
        val mLayoutManager: RecyclerView.LayoutManager = LinearLayoutManager(applicationContext)
        articlesRecycleView.layoutManager = mLayoutManager

           articlesRecycleView.adapter = AlphaInAnimationAdapter(mAdapter)
       // articlesRecycleView.adapter = mAdapter

        // Obtain a reference to the SharedPreferences file for this app
        val prefs: SharedPreferences = getSharedPreferences("filters", 0)

        // PreferenceManager.getDefaultSharedPreferences(this)

        // And register to be notified of preference changes
        // So we know when the user has adjusted the query settings
        prefs.registerOnSharedPreferenceChangeListener(this)

      /*  articlesListView.setOnItemClickListener { parent, view, position, id ->
            // Find the current article that was clicked on
            val article: Article? = mAdapter.getItem(position)

            // Convert the String URL into a URI object (to pass into the Intent constructor)
            var articleUri: Uri? = null
            if (article != null) {
                articleUri = Uri.parse(article.url)
            }

            // Create a new intent to view the news story URI
            val websiteIntent = Intent(Intent.ACTION_VIEW, articleUri)

            // Send the intent to launch a new activity
            startActivity(websiteIntent)
        }*/

       /* articlesListView.setOnScrollListener(object : AbsListView.OnScrollListener {

            override fun onScrollStateChanged(view: AbsListView, scrollState: Int) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE && articlesListView.lastVisiblePosition - articlesListView.headerViewsCount -
                    articlesListView.footerViewsCount >= articlesListView.adapter.count - 1) {

                    articlesToShow += 10

                    loaderManager.initLoader<List<Article>>(ARTICLES_LOADER_ID, null, this@MainActivity)

                    val toast:Toast = Toast.makeText(applicationContext, "works", Toast.LENGTH_SHORT)
                    toast.show()
                }
            }

            override fun onScroll(
                view: AbsListView,
                firstVisibleItem: Int,
                visibleItemCount: Int,
                totalItemCount: Int
            ) {

            }
        })*/

        // Get a reference to the ConnectivityManager to check state of network connectivity
        val cm: ConnectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        // Get details on the currently active default data network
        var networkInfo: NetworkInfo? = cm?.activeNetworkInfo

        // If there is a network connection, fetch data
        if (networkInfo != null && networkInfo.isConnectedOrConnecting) {

            // Get a reference to the LoaderManager, in order to interact with loaders.
            val loaderManager = loaderManager

            // Initialize the loader. Pass in the int ID constant defined above and pass in null for
            // the bundle. Pass in this activity for the LoaderCallbacks parameter (which is valid
            // because this activity implements the LoaderCallbacks interface).
            //Log.i(LOG_TAG, getString(R.string.newsStory_initLoader_log_message));
            loaderManager.initLoader<List<Article>>(ARTICLES_LOADER_ID, null, this)
        } else {
            // Otherwise, display error. First, hide loading indicator so error message will be visible
            loadingSpinner.visibility = View.GONE

            // Update empty state with "no connection" error message
            mEmptyStateTextView.setText(R.string.no_internet_connection)
        }
    }

    override fun onSharedPreferenceChanged(prefs: SharedPreferences, key: String) {
        if (key == getString(R.string.settings_filter_by_key) || key == getString(R.string.settings_order_by_key)) {
            // Clear the ListView as a new query will be kicked off
            mAdapter.clearData(articlesRecycleView)

            // Hide the empty state text view as the loading indicator will be displayed
//            mEmptyStateTextView.visibility = View.GONE

            // Show the loading indicator while new data is being fetched
            loadingSpinner.visibility = View.VISIBLE

            // Restart the loader as the query settings have been updated
            loaderManager.restartLoader(ARTICLES_LOADER_ID, null, this)
        }
    }

    override fun onCreateLoader(i: Int, bundle: Bundle?): Loader<List<Article>> {
        //Log.i(LOG_TAG, getString(R.string.onCreateLoader_log_message));

        val sharedPrefs: SharedPreferences =  getSharedPreferences("filters", 0)

        //PreferenceManager.getDefaultSharedPreferences(this)

        val filterBy: String? = sharedPrefs.getString(
            getString(R.string.settings_filter_by_key),
            ""
        )

        val orderBy: String? = sharedPrefs.getString(
            getString(R.string.settings_order_by_key),
            getString(R.string.settings_order_by_default)
        )

        // Create a new loader for the given URL
        // Build URI reference for for news stories from The Guardian data set
        // http://content.guardianapis.com/search?show-tags=contributor&api-key=test
        val uriBuilder: Uri.Builder = Uri.Builder()
        uriBuilder.scheme("http")
            .authority("content.guardianapis.com")
            .appendPath("search")
            .appendQueryParameter("q", filterBy)
            .appendQueryParameter("show-tags", "contributor")
            .appendQueryParameter("order-by", orderBy)
            .appendQueryParameter("api-key", "test")
            .appendQueryParameter("show-fields", "thumbnail")
            .appendQueryParameter("page-size", articlesToShow.toString())
        if (filterBy!!.isNotEmpty())
            uriBuilder.appendQueryParameter("q", filterBy)

        return ArticlesLoader(this, uriBuilder.build().toString())
    }

    override fun onLoadFinished(loader: Loader<List<Article>>, articles: List<Article>?) {
        //Log.i(LOG_TAG, getString(R.string.onLoadFinished_log_message));

        // Hide loading indicator because the data has been loaded
        loadingSpinner.visibility = View.GONE

        // Set empty state text to display "No news stories found."
        //mEmptyStateTextView.text = R.string.no_articles_found.toString()

        // Clear the adapter of previous news story data
        //mAdapter.clear()
        mAdapter.clearData(articlesRecycleView)

        // If there is a valid list of {@link NewsStory}s, then add them to the adapter's
        // data set. This will trigger the ListView to update.


      /*  for(index in 0 until (articles?.size ?: 0)) {
            articles?.get(index)?.imgBitmap = GlideApp.with(this).asBitmap().load(articles?.get(index)?.imgUrl).submit().get()
        }
*/
        if (articles != null && articles.isNotEmpty()) {
            mAdapter.addItems(articles, articlesRecycleView)
        }
    }

    override fun onLoaderReset(loader: Loader<List<Article>>) {
        //Log.i(LOG_TAG, getString(R.string.onLoaderReset_log_message));
        // Loader reset, so we can clear out our existing data.
        mAdapter.clearData(articlesRecycleView)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id:Int = item.itemId
        if (id == R.id.action_settings) {
            val settingsIntent: Intent = Intent(this, SettingsActivity::class.java)
            startActivity(settingsIntent)
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
