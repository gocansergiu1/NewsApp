package com.example.newsapp

import android.os.Handler
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.annotation.GlideModule
import com.bumptech.glide.module.AppGlideModule
import jp.wasabeef.recyclerview.animators.*
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*


@GlideModule
class MyAppGlideModule : AppGlideModule()

class ArticlesAdapter(articleList: List<Article>) : RecyclerView.Adapter<ArticlesAdapter.ViewHolder>() {

    companion object {
        private val inputDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        private val outputDateFormat = SimpleDateFormat("yyyy-MM-dd  HH:mm", Locale.US)
    }

    val animations = listOf(SlideInRightAnimator(), ScaleInAnimator(), ScaleInTopAnimator(), ScaleInBottomAnimator(),
        ScaleInLeftAnimator(), ScaleInRightAnimator(), FadeInAnimator(), FadeInDownAnimator(), FadeInUpAnimator(),
        FadeInLeftAnimator(), FadeInRightAnimator(), FlipInTopXAnimator(), FlipInBottomXAnimator(),
        FlipInLeftYAnimator(), FlipInRightYAnimator(), SlideInLeftAnimator(), SlideInRightAnimator(), OvershootInLeftAnimator(), OvershootInRightAnimator(),
        SlideInUpAnimator(), SlideInDownAnimator())

    var articlesList: MutableList<Article>
    lateinit var itemView: View

    class ViewHolder(v: View): RecyclerView.ViewHolder(v) {
         var titleTextView: TextView
         var sectionTextView: TextView
         var authorTextView: TextView
         var dateTextView: TextView
         var thumbnailImageView: ImageView

        init {
            titleTextView = v.findViewById(R.id.title)
            sectionTextView = v.findViewById(R.id.section)
            authorTextView = v.findViewById(R.id.author)
            dateTextView = v.findViewById(R.id.date)
            thumbnailImageView = v.findViewById(R.id.thumbnail)
        }
    }

    init {
        articlesList = articleList.toMutableList()
    }

    fun clearData(recyc: RecyclerView? = null) {

        recyc?.itemAnimator = SlideInRightAnimator()

        for (index in (articlesList.size-1) downTo 0){

            val handler = Handler()
            handler.postDelayed(Runnable {
                articlesList.removeAt(index)
                notifyItemRemoved(index)
                recyc?.scrollToPosition(index)
                recyc?.itemAnimator = animations[index]


            }, 500 * (articlesList.size-index).toLong())
        }

        //articlesList.clear()
        //notifyItemRangeRemoved(0, articlesList.size)

        //notifyDataSetChanged()
    }

    fun addItems(articles: List<Article>, recyc: RecyclerView? = null) {
        recyc?.itemAnimator = SlideInLeftAnimator()
        recyc?.itemAnimator?.apply {
            addDuration = 300
        }

        for (index in 0 until articles.size){
            val handler = Handler()
            handler.postDelayed(Runnable {
                articlesList.add(articles[index])
                notifyItemInserted(index)
                recyc?.scrollToPosition(index)
                //recyc?.itemAnimator = animations[index]

            }, 300 * (index+1).toLong())
        }

        //articlesList.addAll(articles)
       // notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
       itemView = LayoutInflater.from(parent.context).inflate(R.layout.article, parent, false)
        return ViewHolder(itemView)
    }

    override fun getItemCount(): Int {
        return articlesList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val article = articlesList[position]

        Glide.with(itemView)
            .load(article.imgUrl)
            .error(R.drawable.area51gf_meme)
            .into(holder.thumbnailImageView)
        //holder.thumbnailImageView.setImageBitmap(article.imgBitmap)

        // Display the title of the current article in that TextView
        holder.titleTextView.text = article.title
        //Display the section of the current article in that TextView
        holder.sectionTextView.text = article.section
        //Display the author of the current article in that TextView
        holder.authorTextView.text = article.author

        //Parse the String which holds the date and time (original "2018-04-15T08:35:35Z" to
        //"2018-04-15" and "08:35:35", and from "08:35:35" to "08:35")
        val originalDate: String = article.publicationDate
        try {
            val d: Date? = inputDateFormat.parse(originalDate)
            val formattedDateTime: String = outputDateFormat.format(d!!)

            // Display the date of the current news story in that TextView
            holder.dateTextView.text = formattedDateTime
        } catch (e: ParseException) {
            e.printStackTrace()
        }
    }
}