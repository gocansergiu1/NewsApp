package com.example.newsapp

import android.graphics.Bitmap
import android.text.TextUtils
import android.util.Log
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.URL
import java.nio.charset.Charset

/**
 * Helper methods related to requesting and receiving articles from The Guardian site.
 */
object QueryUtils {

    /** Tag for the log messages  */
    private val LOG_TAG: String = QueryUtils::class.java.simpleName

    private const val RESPONSE: String = "response"
    private const val RESULTS: String = "results"
    private const val WEB_TITLE: String = "webTitle"
    private const val SECTION_NAME: String = "sectionName"
    private const val WEB_PUBLICATION_DATE: String = "webPublicationDate"
    private const val WEB_URL: String = "webUrl"
    private const val READ_TIMEOUT: Int = 10000  /* milliseconds */
    private const val CONNECT_TIMEOUT: Int = 15000  /* milliseconds */
    private const val GET_REQUEST_METHOD: String = "GET"

    /**
     * Query the Guardian data set and return a list of [Article] objects.
     */
    fun fetchArticles(requestUrl: String): List<Article>? {
        // Create URL object
        val url: URL? = createUrl(requestUrl)

        // Perform HTTP request to the URL and receive a JSON response back
        var jsonResponse: String? = null
        try {
            jsonResponse = makeHttpRequest(url)
        } catch (e: IOException) {
            Log.e(LOG_TAG, "Problem making the HTTP request.", e)
        }

        // Extract relevant fields from the JSON response and create a list of {@link Article}s
        //return the list of {@link Article}s
        return extractArticlesFromJson(jsonResponse)
    }

    /**
     * Returns new URL object from the given string URL.
     */
    private fun createUrl(stringUrl: String): URL? {
        var url: URL? = null
        try {
            url = URL(stringUrl)
        } catch (e: MalformedURLException) {
            Log.e(LOG_TAG, "Problem building the URL ", e)
        }

        return url
    }

    /**
     * Make an HTTP request to the given URL and return a String as the response.
     */
    @Throws(IOException::class)
    private fun makeHttpRequest(url: URL?): String {
        var jsonResponse: String = ""

        // If the URL is null, then return early.
        if (url == null) {
            return jsonResponse
        }

        var urlConnection: HttpURLConnection? = null
        var inputStream: InputStream? = null
        try {
            urlConnection = url.openConnection() as HttpURLConnection
            urlConnection.readTimeout = READ_TIMEOUT
            urlConnection.connectTimeout = CONNECT_TIMEOUT
            urlConnection.requestMethod = GET_REQUEST_METHOD
            urlConnection.connect()

            // If the request was successful (response code 200),
            // then read the input stream and parse the response.
            if (urlConnection.responseCode == HttpURLConnection.HTTP_OK) {
                inputStream = urlConnection.inputStream
                jsonResponse = readFromStream(inputStream)
            } else {
                Log.e(LOG_TAG, "Error response code: " + urlConnection.responseCode)
            }
        } catch (e: IOException) {
            Log.e(LOG_TAG, "Problem retrieving the articles JSON results.", e)
        } finally {
            urlConnection?.disconnect()
            inputStream?.close()
        }
        return jsonResponse
    }

    /**
     * Convert the [InputStream] into a String which contains the
     * whole JSON response from the server.
     */
    @Throws(IOException::class)
    private fun readFromStream(inputStream: InputStream?): String {
        val output = StringBuilder()
        if (inputStream != null) {
            val inputStreamReader = InputStreamReader(inputStream, Charset.forName("UTF-8"))
            val reader = BufferedReader(inputStreamReader)
            var line: String? = reader.readLine()
            while (line != null) {
                output.append(line)
                line = reader.readLine()
            }
        }
        return output.toString()
    }

    /**
     * Return a list of [Article] objects that has been built up from
     * parsing the given JSON response.
     */
    private fun extractArticlesFromJson(articlesJSON: String?): List<Article>? {

        // If the JSON string is empty or null, then return early.
        if (TextUtils.isEmpty(articlesJSON)) {
            return null
        }

        // Create an empty ArrayList that we can start adding articles to
        val articles: MutableList<Article> =  mutableListOf()

        // Try to parse the JSON response string. If there's a problem with the way the JSON
        // is formatted, a JSONException exception object will be thrown.
        // Catch the exception so the app doesn't crash, and print the error message to the logs.
        try {

            // Create a JSONObject from the JSON response string
            val baseJsonResponse: JSONObject = JSONObject(articlesJSON!!)

            //Extract the JSONArray associated with the key "response" which represents a list
            //of JSONObject
            val articlesArray: JSONObject = baseJsonResponse.getJSONObject(RESPONSE)
            //Extract the JSONArray associated with the key "result" which represents a list
            //of JSONArray
            val resultsArray: JSONArray = articlesArray.getJSONArray(RESULTS)

            //For each article in the articlesArray, create a {@link Article} object
            for (i in 0 until resultsArray.length()) {
                val resultObj = resultsArray.getJSONObject(i)

                val title: String = resultObj.getString(WEB_TITLE)
                val section: String = resultObj.getString(SECTION_NAME)
                val publicationDate: String = resultObj.getString(WEB_PUBLICATION_DATE)
                // Extract the value for the key called "webUrl"
                val url: String = resultObj.getString(WEB_URL)

                val tagsArray:JSONArray = resultObj.getJSONArray("tags")

                val author: String =  if(tagsArray.length() > 0) tagsArray.getJSONObject(0).getString(WEB_TITLE) else "Author unknown"

                val thumbnail: String = if(resultObj.has("fields")) resultObj.getJSONObject("fields").getString("thumbnail") else ""

                /*val imgBitmap = GlideApp.with(MainActivity().applicationContext).asBitmap().load(thumbnail).submit().get()*/

                // Create a new {@link Article} object with the title, section, publicationDate,
                // and url from the JSON response.
                val article: Article = Article(title, section, publicationDate, url, author, thumbnail)
                articles.add(article)
            }

        } catch (e: JSONException) {
            // If an error is thrown when executing any of the above statements in the "try" block,
            // catch the exception here, so the app doesn't crash. Print a log message
            // with the message from the exception.
            Log.e("QueryUtils", "Problem parsing the articles JSON results", e)
        }

        // Return the list of articles
        return articles
    }
}

