package com.example.newsapp

import android.content.AsyncTaskLoader
import android.content.Context

/**
 * Loads a list of articles by using an AsyncTask to perform the
 * network request to the given URL.
 */
class ArticlesLoader
/**
 * Constructs a new [ArticlesLoader].
 *
 * @param context of the activity
 * @param url to load data from
 */
    (
    context: Context,
    /** Query URL  */
    private val mUrl: String?
) : AsyncTaskLoader<List<Article>>(context) {

    override fun onStartLoading() {
        forceLoad()
    }

    /**
     * This is on a background thread
     */
    override fun loadInBackground(): List<Article>? {
        return if (mUrl == null) {
            null
        } else {
      /* *//*     val mockArticles: MutableList<Article> = mutableListOf()
            for (i in 1..100) {
                mockArticles.add(Article("Title " + i, "Section " + i, Date().toString(), "www.google.com","Someone " + i))
            }*//*
            //mockArticles*/

            val articles = QueryUtils.fetchArticles(mUrl)
          /*  for(index in 0 until (articles?.size ?: 0)) {
                articles?.get(index)?.imgBitmap = GlideApp.with(context).asBitmap().load(articles?.get(index)?.imgUrl).submit().get()
            }*/
            articles

        }

        // Perform the network request, parse the response, and extract a list of articles.
    }
}

