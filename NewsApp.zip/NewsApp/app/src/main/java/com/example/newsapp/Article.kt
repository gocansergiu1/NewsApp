package com.example.newsapp

import android.graphics.Bitmap

data class Article(
    val title: String,
    val section: String,
    val publicationDate: String,
    val url: String,
    val author: String,
    val imgUrl: String,
    var imgBitmap: Bitmap? = null
)
